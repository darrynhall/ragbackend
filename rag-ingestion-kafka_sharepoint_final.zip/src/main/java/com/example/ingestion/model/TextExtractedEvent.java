package com.example.ingestion.model;

public record TextExtractedEvent(String filename, String text, String userId) {}

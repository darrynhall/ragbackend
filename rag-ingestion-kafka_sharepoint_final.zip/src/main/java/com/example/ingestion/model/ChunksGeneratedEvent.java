package com.example.ingestion.model;

import java.util.List;

public record ChunksGeneratedEvent(String filename, List<String> chunks, String userId) {}

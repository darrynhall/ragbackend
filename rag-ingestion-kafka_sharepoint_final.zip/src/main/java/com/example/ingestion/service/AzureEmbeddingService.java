package com.example.ingestion.service;

import com.azure.ai.openai.OpenAIClient;
import com.azure.ai.openai.models.Embedding;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AzureEmbeddingService implements EmbeddingService {

    private final OpenAIClient openAIClient;

    @Override
    public List<float[]> embed(List<String> chunks) {
        return chunks.stream()
            .map(chunk -> openAIClient.getEmbeddings(chunk)
                .getData()
                .stream()
                .flatMap(Embedding::getEmbeddingStream)
                .mapToFloat(Float::floatValue)
                .toArray())
            .collect(Collectors.toList());
    }
}
